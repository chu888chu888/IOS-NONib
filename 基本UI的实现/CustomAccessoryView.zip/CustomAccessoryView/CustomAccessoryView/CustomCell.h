//
//  CustomCell.h
//  CustomAccessoryView
//
//  Created by wuzhangfu on 14-1-10.
//  Copyright (c) 2014年 Smartisan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCell : UITableViewCell
- (void)setEditing:(BOOL)editing animated:(BOOL)animated;
@end
