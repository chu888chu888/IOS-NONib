//
//  ViewController.m
//  CustomAccessoryView
//
//  Created by wuzhangfu on 14-1-10.
//  Copyright (c) 2014年 Smartisan. All rights reserved.
//

#import "ViewController.h"
#import "CustomCell.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate>{
    UITableView *tbView;
}
@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *setEditing = [[UIButton alloc] initWithFrame:CGRectMake(0, 20, 159, 44)];
    [setEditing setTitle:@"setEditing" forState:UIControlStateNormal];
    setEditing.backgroundColor = [UIColor darkGrayColor];
    [setEditing addTarget:self action:@selector(setEditing) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:setEditing];
    
    UIButton *cancelEditing = [[UIButton alloc] initWithFrame:CGRectMake(161, 20, 160, 44)];
    [cancelEditing setTitle:@"cancelEditing" forState:UIControlStateNormal];
    cancelEditing.backgroundColor = [UIColor darkGrayColor];
    [cancelEditing addTarget:self action:@selector(cancelEditing) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:cancelEditing];
    
    tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 20+44, 320, self.view.frame.size.height-64)];
    [self.view addSubview:tbView];
    tbView.delegate = self;
    tbView.dataSource = self;
}

- (void)setEditing{
    [tbView setEditing:YES];
}

- (void)cancelEditing{
    [tbView setEditing:NO];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 20;
}

- (CustomCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifer = @"cellIdentifer";
    CustomCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifer];
    if (cell == nil) {
        cell = [[CustomCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifer];
    }
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath{
    NSLog(@"moveRowAtIndexPath: %d toIndexPath: %d", sourceIndexPath.row, destinationIndexPath.row);
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleNone;
    //return UITableViewCellEditingStyleDelete; // will add Red Delete Button, default is Delete
    //return UITableViewCellEditingStyleInsert; // will add Green Add Button
}

@end


