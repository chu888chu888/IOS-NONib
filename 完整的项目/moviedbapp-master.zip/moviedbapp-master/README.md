# MovieDBApp
MovieDB is a sample app implementing several UI patterns.
I was firstly built to test a few different implementations of a details page.

![Alt text](https://raw.githubusercontent.com/KMindeguia/moviedbapp/master/Screeshots/sc1.png?raw=true "Optional title")
![Alt text](https://raw.githubusercontent.com/KMindeguia/moviedbapp/master/Screeshots/sc2.png?raw=true "Optional title")
![Alt text](https://raw.githubusercontent.com/KMindeguia/moviedbapp/master/Screeshots/sc3.png?raw=true "Optional title")
![Alt text](https://raw.githubusercontent.com/KMindeguia/moviedbapp/master/Screeshots/sc4.png?raw=true "Optional title")
![Alt text](https://raw.githubusercontent.com/KMindeguia/moviedbapp/master/Screeshots/sc5.png?raw=true "Optional title")
![Alt text](https://raw.githubusercontent.com/KMindeguia/moviedbapp/master/Screeshots/sc6.png?raw=true "Optional title")

Copyright (c) 2014 Kevin Mindeguia
