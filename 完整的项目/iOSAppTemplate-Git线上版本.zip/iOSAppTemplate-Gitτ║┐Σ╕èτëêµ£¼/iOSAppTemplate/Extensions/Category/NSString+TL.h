//
//  NSString+WB.h
//  WhichBank
//
//  Created by h1r0 on 15/9/8.
//  Copyright (c) 2015年 lettai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (TL)

- (NSString *) pinyin;
- (NSString *) pinyinInitial;

@end
