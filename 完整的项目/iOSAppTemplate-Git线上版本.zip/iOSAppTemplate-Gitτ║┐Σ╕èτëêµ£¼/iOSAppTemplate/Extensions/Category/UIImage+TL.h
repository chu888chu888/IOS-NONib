//
//  UIImage+WB.h
//  WhichBank
//
//  Created by h1r0 on 15/9/6.
//  Copyright (c) 2015年 lettai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (TL)

+ (UIImage *)imageWithColor:(UIColor *)color;

@end
