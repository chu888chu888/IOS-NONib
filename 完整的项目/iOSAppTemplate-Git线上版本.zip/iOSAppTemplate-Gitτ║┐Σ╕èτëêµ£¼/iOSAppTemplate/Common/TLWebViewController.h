//
//  TLWebViewController.h
//  iOSAppTemplate
//
//  Created by h1r0 on 15/9/19.
//  Copyright (c) 2015年 lbk. All rights reserved.
//

#import "CommonViewController.h"

@interface TLWebViewController : CommonViewController

@property (nonatomic, strong) UIWebView *webView;

@property (nonatomic, strong) NSString *urlString;

@end
