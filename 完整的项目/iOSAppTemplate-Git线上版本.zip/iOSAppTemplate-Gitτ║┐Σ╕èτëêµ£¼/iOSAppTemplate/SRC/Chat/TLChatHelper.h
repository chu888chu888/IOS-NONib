//
//  TLChatHelper.h
//  iOSAppTemplate
//
//  Created by libokun on 15/10/20.
//  Copyright (c) 2015年 lbk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TLChatHelper : NSObject

+ (NSAttributedString *) formatMessageString:(NSString *)text;

@end
