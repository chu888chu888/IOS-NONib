//
//  TLDetailsSettingViewController.h
//  iOSAppTemplate
//
//  Created by libokun on 15/9/30.
//  Copyright (c) 2015年 lbk. All rights reserved.
//

#import "CommonTableViewController.h"

@interface TLDetailsSettingViewController : CommonTableViewController

@end
