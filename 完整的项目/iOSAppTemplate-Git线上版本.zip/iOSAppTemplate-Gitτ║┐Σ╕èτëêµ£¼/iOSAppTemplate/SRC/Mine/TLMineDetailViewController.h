//
//  TLMineDetailViewController.h
//  iOSAppTemplate
//
//  Created by 李伯坤 on 15/9/30.
//  Copyright (c) 2015年 lbk. All rights reserved.
//

#import "CommonTableViewController.h"

@interface TLMineDetailViewController : CommonTableViewController


@end
