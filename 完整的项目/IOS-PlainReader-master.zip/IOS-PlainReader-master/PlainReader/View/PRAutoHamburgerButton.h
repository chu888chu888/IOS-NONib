//
//  PRAutoHamburgerButton.h
//  PlainReader
//
//  Created by guo on 11/29/14.
//  Copyright (c) 2014 guojiubo. All rights reserved.
//

#import "PRHamburgerButton.h"

@interface PRAutoHamburgerButton : PRHamburgerButton

@end
