//
//  WeeklyViewController.h
//  PlainReader
//
//  Created by guojiubo on 14-4-10.
//  Copyright (c) 2014年 guojiubo. All rights reserved.
//

#import "PRPullToRefreshViewController.h"

@interface PRWeeklyViewController : PRPullToRefreshViewController

@end
