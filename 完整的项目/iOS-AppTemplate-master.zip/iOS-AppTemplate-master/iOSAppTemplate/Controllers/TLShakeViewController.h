//
//  TLShakeViewController.h
//  iOSAppTemplate
//
//  Created by libokun on 15/10/2.
//  Copyright (c) 2015年 lbk. All rights reserved.
//

#import "CommonViewController.h"

@interface TLShakeViewController : CommonViewController

@end
