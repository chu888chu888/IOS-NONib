//
//  TLInputBoxViewController.m
//  iOSAppTemplate
//
//  Created by 李伯坤 on 15/9/24.
//  Copyright (c) 2015年 lbk. All rights reserved.
//

#import "TLInputBoxViewController.h"

@implementation TLInputBoxViewController

- (void) viewDidLoad
{
    [super viewDidLoad];
    
    [self.view setBackgroundColor:DEFAULT_BACKGROUND_COLOR];
}

@end
