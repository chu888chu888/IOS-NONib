//
//  TLDiscoverViewController.h
//  iOSAppTemplate
//
//  Created by h1r0 on 15/9/17.
//  Copyright (c) 2015年 lbk. All rights reserved.
//

#import "CommonTableViewController.h"

@interface TLDiscoverViewController : CommonTableViewController

@property (nonatomic, strong) NSMutableArray *data;

@end
