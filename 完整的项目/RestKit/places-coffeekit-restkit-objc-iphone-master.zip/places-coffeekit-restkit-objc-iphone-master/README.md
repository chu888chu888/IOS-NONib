# A find near by coffee shop demo for iPhone with Objective C, RestKit, Xcode 6 and iOS 8, tutorial by Scott @raywenderlich.com

**Tutorial By Scott**

[Introduction to RestKit Tutorial](http://www.raywenderlich.com/58682/introduction-restkit-tutorial)

**Credits**

Tutorial and source code by [Scott](http://www.raywenderlich.com/u/scott4arrows)
