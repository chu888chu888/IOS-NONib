//
//  MasterViewController.h
//  coffeekit
//
//  Created by giaunv on 4/3/15.
//  Copyright (c) 2015 366. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController


@end

