//
//  Venue.m
//  coffeekit
//
//  Created by giaunv on 4/3/15.
//  Copyright (c) 2015 366. All rights reserved.
//

#import "Venue.h"

@implementation Venue

@end
