//
//  Stats.h
//  RestKitTutorial
//
//  Created by Sergey Yuzepovich on 27.12.14.
//  Copyright (c) 2014 Sergey Yuzepovich. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Stats : NSObject
@property (nonatomic, strong) NSNumber *checkins;
@property (nonatomic, strong) NSNumber *tips;
@property (nonatomic, strong) NSNumber *users;

@end
