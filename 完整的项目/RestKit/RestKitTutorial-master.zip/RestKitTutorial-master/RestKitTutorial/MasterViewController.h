//
//  MasterViewController.h
//  RestKitTutorial
//
//  Created by Sergey Yuzepovich on 27.12.14.
//  Copyright (c) 2014 Sergey Yuzepovich. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController


@end

