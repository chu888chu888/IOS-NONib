//
//  DHSmartScreenshot.h
//  TableViewScreenshots
//
//  Created by Hernandez Alvarez, David on 12/3/13.
//  Copyright (c) 2013 David Hernandez. All rights reserved.
//

#ifndef TableViewScreenshots_DHSmartScreenshot_h
#define TableViewScreenshots_DHSmartScreenshot_h

#import "UITableView+DHSmartScreenshot.h"
#import "UIScrollView+DHSmartScreenshot.h"

#endif
