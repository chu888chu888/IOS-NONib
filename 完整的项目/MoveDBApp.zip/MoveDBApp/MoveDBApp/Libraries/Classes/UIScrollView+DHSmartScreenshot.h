//
//  UITableView+Screenshot.h
//  Kiwi
//
//  Created by Marcin Stepnowski on 10/11/14.
//  Copyright (c) 2014 Marcin Stepnowski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (DHSmartScreenshot)

-(UIImage*)screenshotOfVisibleContent;

@end
