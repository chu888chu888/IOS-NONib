//
//  WNXUserInfoDetailViewController.h
//  WNXHuntForCity
//
//  Created by MacBook on 15/7/16.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.
//  这里用到了scrollView,而scrollView的自动布局太烦，所以直接代码来实现自动布局了

#import <UIKit/UIKit.h>

@interface WNXUserInfoDetailViewController : UIViewController

@end
