//
//  WNXCollectionViewController.m
//  WNXHuntForCity
//
//  Created by MacBook on 15/6/30.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.
//

#import "WNXCollectionViewController.h"

@interface WNXCollectionViewController ()

@end

@implementation WNXCollectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"收藏";
    self.navigationItem.rightBarButtonItem = nil;
}


@end
