//
//  WNXDoubleTextView.h
//  WNXHuntForCity
//
//  Created by MacBook on 15/7/2.
//  Copyright (c) 2015年 维尼的小熊. All rights reserved.


#import <UIKit/UIKit.h>

@interface WNXDoubleTextView : UIView

//设置文字内容
- (void)setTitle:(NSString *)title subTitle:(NSString *)subTitle;

@end
