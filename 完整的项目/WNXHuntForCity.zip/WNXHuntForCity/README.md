# iOS高仿城觅项目（开发思路和代码）
![抽屉](http://ww3.sinaimg.cn/mw690/0068uRu1gw1euafbypbwfg307r0eanpd.gif)
![首页部分效果](http://ww2.sinaimg.cn/mw690/0068uRu1gw1euafbuoga1g307r0ea4qq.gif)
![首页效果](http://ww3.sinaimg.cn/mw690/0068uRu1gw1euafcdouwvg307r0ea7lo.gif)
![部分效果](http://ww1.sinaimg.cn/mw690/0068uRu1gw1euafd13tbjg307r0eau0y.gif)
![发现](http://ww1.sinaimg.cn/mw690/0068uRu1gw1euafcmh1l6g307r0eae81.gif)
![消息](http://ww2.sinaimg.cn/mw690/0068uRu1gw1eu74j4wthpg307r0ea7j8.gif)
![搜索](http://ww2.sinaimg.cn/mw690/0068uRu1gw1eu79mzig0xg307r0eadix.gif)
![设置](http://ww3.sinaimg.cn/mw690/0068uRu1gw1euafcuka9ug307r0eatdy.gif)
![模糊效果](http://ww3.sinaimg.cn/mw690/0068uRu1gw1euag0qdr3yg307i0dpb29.gif)
![代码注释展示](http://ww4.sinaimg.cn/mw690/0068uRu1gw1eu74eo2alej31kw0yx7oy.jpg)
![代码注释展示](http://ww3.sinaimg.cn/mw690/0068uRu1gw1eu74egddlqj31kw0yn18a.jpg)
 还有很多细节就不一一展示了,大家将代码运行下自己查看即可.
 
 ###文章链接

#### [城觅,点击链接当前博客](http://www.jianshu.com/p/8b0d694d1c69)
#####如有任何问题都可以在博客下留言，我会逐一回复

#### [点击链接gitHub](http://www.jianshu.com/p/d5ea6c9d65fd)
##### 希望小手能顺便点一下右上角的⭐️Star ^_^，朋友的鼓励和支持是我继续分享的动力

#### [我的微博](http://weibo.com/5622363113/profile?rightmod=1&wvr=6&mod=personinfo)


####请直接打开`WNXHuntForCity.xcworkspace`运行工程![打开](http://ww4.sinaimg.cn/mw690/0068uRu1gw1eu7cyp74l7j307k06eaac.jpg)而不要打开`WNXHuntForCity.xcodeproj`
